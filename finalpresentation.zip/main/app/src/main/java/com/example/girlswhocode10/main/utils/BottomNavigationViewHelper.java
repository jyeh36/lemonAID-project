package com.example.girlswhocode10.main.utils;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.util.Log;
import android.view.MenuItem;

import com.example.girlswhocode10.main.R;
import com.example.girlswhocode10.main.forum;
import com.example.girlswhocode10.main.homeactivity;
import com.example.girlswhocode10.main.moodtracker;
import com.example.girlswhocode10.main.profile;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class BottomNavigationViewHelper {

    private static final String TAG = "BottomNavigationViewHel";

    public static void setupBottomNavigationView(BottomNavigationViewEx bottomNavigationViewEx){
        Log.d(TAG,"setupBottomNavigationView: Setting up BottomNavigationView:");
        bottomNavigationViewEx.enableAnimation(false);
        bottomNavigationViewEx.enableItemShiftingMode(false);
        bottomNavigationViewEx.enableShiftingMode(false);
        bottomNavigationViewEx.setTextVisibility(false);
    }
    public static void enablenavigation(final Context context, BottomNavigationViewEx view) {
       view.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
           @Override
           public boolean onNavigationItemSelected(@NonNull MenuItem item) {
               switch (item.getItemId()) {

                   case R.id.ic_house:
                       Intent gotohomepage = new Intent(context, homeactivity.class);
                       context.startActivity(gotohomepage);
                       break;

                   case R.id.ic_forum:
                       Intent gotoforumpage = new Intent(context, forum.class);
                       context.startActivity(gotoforumpage);
                       break;

                   case R.id.ic_mood:
                       Intent gotomoodtrackerpage = new Intent(context, moodtracker.class);
                       context.startActivity(gotomoodtrackerpage);
                       break;

                   case R.id.ic_profile:
                       Intent gotoprofilepage = new Intent(context, profile.class);
                       context.startActivity(gotoprofilepage);
                       break;
               }
               return false;
           }
       });
    }
}
