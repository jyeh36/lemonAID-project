package com.example.girlswhocode10.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.girlswhocode10.main.utils.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import static com.example.girlswhocode10.main.R.menu.bottom_navigation_menu;


public class homeactivity extends AppCompatActivity {

    private static final String TAG = "homeactivity";
    private static final int ACTIVITY_NUM = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button newButton = (Button) findViewById(R.id.quotes_button);
        newButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent StartIntent = new Intent(getApplicationContext(), activity1.class);
                startActivity(StartIntent);
            }
        });

//      public void onCreate(Bundle savedInstanceState) {
//            super.onCreate(savedInstanceState);
//            setContentView(R.layout.layout_bottom_navigation_view);

//        }
//
//        public boolean onCreateOptionsMenu(Menu menu) {
//            MenuInflater inflater = getMenuInflater();
//            inflater.inflate(bottom_navigation_menu, menu);
//            return true;
//        }
//
//        public boolean onOptionsItemSelected(MenuItem item){
//            switch (item.getItemId()) {
//                case R.id.ic_house:
//                    startActivity(new Intent(this, homeactivity.class));
//                    return true;
//                case R.id.ic_forum:
//                    startActivity(new Intent(this, forum.class));
//                    return true;
//                case R.id.ic_mood:
//                    startActivity(new Intent(this, moodtracker.class));
//                    return true;
//                case R.id.ic_profile:
//                    startActivity(new Intent(this, profile.class));
//                    return true;
//
//                default:
//                    return super.onOptionsItemSelected(item);
//            }
//        }

        Button StoriesButton = (Button) findViewById(R.id.stories_button);
        StoriesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent NewIntent = new Intent(getApplicationContext(), activity2.class);
                startActivity(NewIntent);
            }
        });

        Button VideosButton = (Button) findViewById(R.id.videos_button);
        VideosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VideoScreen = new Intent(getApplicationContext(), activity3.class);
                startActivity(VideoScreen);


            }
        });





        Log.d(TAG,"onCreate: starting:");

        setupBottomNavigationView();
    }
    /**
     * BottomNavigationView setup
     */
    private void setupBottomNavigationView(){
        Log.d(TAG,"setupBottomNavigatonView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enablenavigation(homeactivity.this, bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);
    }
}
