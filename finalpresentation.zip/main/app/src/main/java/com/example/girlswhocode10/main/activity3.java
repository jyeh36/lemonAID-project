package com.example.girlswhocode10.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.girlswhocode10.main.utils.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class activity3 extends AppCompatActivity {

    private static final String TAG = "homeactivity";
//    private static final int ACTIVITY_NUM = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);
        ImageButton PlayButton1 = (ImageButton) findViewById(R.id.play_button_1);
        PlayButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Video1 = "https://www.youtube.com/watch?v=eHl7jMIFDpU";
                Uri videoaddress1 = Uri.parse(Video1);

                Intent GoToVideo1 = new Intent(Intent.ACTION_VIEW, videoaddress1);
                if (GoToVideo1.resolveActivity(getPackageManager()) != null) {
                    startActivity(GoToVideo1);
                }
            }
        });
        ImageButton PlayButton2 = (ImageButton) findViewById(R.id.play_button_4);
        PlayButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Video2 = "https://www.youtube.com/watch?v=6ow3L39Wxmg";
                Uri videoaddress2 = Uri.parse(Video2);

                Intent GoToVideo2 = new Intent(Intent.ACTION_VIEW, videoaddress2);
                if (GoToVideo2.resolveActivity(getPackageManager()) != null) {
                    startActivity(GoToVideo2);
                }
            }
        });
        ImageButton PlayButton3 = (ImageButton) findViewById(R.id.play_button_3);
        PlayButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Video3 = "https://www.youtube.com/watch?v=rdGpT1pIJlw";
                Uri videoaddress3 = Uri.parse(Video3);

                Intent GoToVideo3 = new Intent(Intent.ACTION_VIEW, videoaddress3);
                if (GoToVideo3.resolveActivity(getPackageManager()) != null) {
                    startActivity(GoToVideo3);
                }
            }
        });
        Log.d(TAG,"onCreate: starting:");

        setupBottomNavigationView();
    }


    /**
     * BottomNavigationView setup
     */
    private void setupBottomNavigationView(){
        Log.d(TAG,"setupBottomNavigatonView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enablenavigation(activity3.this, bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
//        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
//        menuItem.setChecked(true);


    }



}
